/*
  CONFIG.JS
  ---------
  Edit this file only. Every page pulls its doctor details, contact numbers
  and links from here, so you never have to hunt through HTML to update
  something later.

  Anything in [SQUARE BRACKETS] is a placeholder — replace it with your
  real information before the site goes live. Everything else below is
  what you provided.
*/

const CONFIG = {
  DOCTOR_NAME: "Dr. Shubham Shelke",
  QUALIFICATION: "MBBS",
  MEDICAL_COLLEGE: "MIMSR Medical College, Latur",
  REGISTRATION_NUMBER: "[MEDICAL REGISTRATION NUMBER]",

  PHONE_NUMBER: "9112750933",
  WHATSAPP_NUMBER: "919112750933", // country code + number, no + or spaces, used for wa.me links
  EMAIL: "shubhamshelke312@gmail.com",

  CLINIC_NAME: "[CLINIC NAME]",
  CLINIC_ADDRESS: "[CLINIC ADDRESS]",
  CONSULTATION_TIMINGS: "[CONSULTATION TIMINGS, e.g. Mon–Sat, 10:00 AM – 2:00 PM & 6:00 PM – 9:00 PM]",
  LANGUAGES_SPOKEN: "[LANGUAGES SPOKEN, e.g. English, Hindi, Marathi]",
  AREAS_OF_INTEREST: "[AREAS OF CLINICAL INTEREST]",

  GOOGLE_MAPS_URL: "[GOOGLE MAPS EMBED / SHARE URL]",

  INSTAGRAM_URL: "[INSTAGRAM URL]",
  FACEBOOK_URL: "[FACEBOOK URL]",
  YOUTUBE_URL: "[YOUTUBE URL]",
  LINKEDIN_URL: "[LINKEDIN URL]",
};
