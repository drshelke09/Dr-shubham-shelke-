/*
  MAIN.JS
  -------
  Handles:
  1. Injecting CONFIG values into any element marked with data-cfg / data-cfg-href
  2. Mobile navigation toggle
  3. FAQ accordion
  4. Appointment form -> WhatsApp message
  5. Patient request/complaint form -> WhatsApp message
  6. Footer year

  No patient data is stored anywhere (no localStorage, no backend call).
  Submitting a form only builds a WhatsApp message and opens wa.me —
  nothing is saved by this website.
*/

document.addEventListener("DOMContentLoaded", () => {
  injectConfig();
  setupNav();
  setupFAQ();
  setupAppointmentForm();
  setupComplaintForm();
  setYear();
});

function injectConfig() {
  document.querySelectorAll("[data-cfg]").forEach((el) => {
    const key = el.getAttribute("data-cfg");
    if (CONFIG[key] !== undefined) el.textContent = CONFIG[key];
  });

  document.querySelectorAll("[data-cfg-href]").forEach((el) => {
    const type = el.getAttribute("data-cfg-href");
    if (type === "tel") {
      el.href = `tel:+${CONFIG.WHATSAPP_NUMBER.length === 12 ? CONFIG.WHATSAPP_NUMBER : CONFIG.PHONE_NUMBER}`;
    } else if (type === "whatsapp") {
      el.href = `https://wa.me/${CONFIG.WHATSAPP_NUMBER}`;
    } else if (type === "email") {
      el.href = `mailto:${CONFIG.EMAIL}`;
    } else if (type === "maps") {
      el.href = CONFIG.GOOGLE_MAPS_URL;
    } else if (type === "instagram") {
      el.href = CONFIG.INSTAGRAM_URL;
    } else if (type === "facebook") {
      el.href = CONFIG.FACEBOOK_URL;
    } else if (type === "youtube") {
      el.href = CONFIG.YOUTUBE_URL;
    } else if (type === "linkedin") {
      el.href = CONFIG.LINKEDIN_URL;
    }
  });
}

function setupNav() {
  const toggle = document.querySelector(".menu-toggle");
  const links = document.querySelector(".nav-links");
  if (!toggle || !links) return;
  toggle.addEventListener("click", () => {
    const open = links.classList.toggle("open");
    toggle.setAttribute("aria-expanded", open ? "true" : "false");
  });
  links.querySelectorAll("a").forEach((a) =>
    a.addEventListener("click", () => links.classList.remove("open"))
  );
}

function setupFAQ() {
  document.querySelectorAll(".faq-item").forEach((item) => {
    const question = item.querySelector(".faq-question");
    question.addEventListener("click", () => {
      const isOpen = item.classList.contains("open");
      document.querySelectorAll(".faq-item.open").forEach((openItem) => {
        if (openItem !== item) openItem.classList.remove("open");
      });
      item.classList.toggle("open", !isOpen);
    });
  });
}

function setupAppointmentForm() {
  const form = document.getElementById("appointment-form");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const f = new FormData(form);
    const message =
      `NEW APPOINTMENT REQUEST\n\n` +
      `Patient Name: ${f.get("name")}\n` +
      `Age: ${f.get("age")}\n` +
      `Gender: ${f.get("gender")}\n` +
      `Mobile: ${f.get("mobile")}\n` +
      `Category: ${f.get("category")}\n` +
      `Preferred Date: ${f.get("date")}\n` +
      `Preferred Time: ${f.get("time")}\n` +
      `Reason for Visit: ${f.get("reason")}\n` +
      `Patient Type: ${f.get("patientType")}\n\n` +
      `Please confirm the available appointment slot.`;
    window.open(`https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank");
    form.reset();
    showFormNote("appointment-note");
  });
}

function setupComplaintForm() {
  const form = document.getElementById("complaint-form");
  if (!form) return;
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const f = new FormData(form);
    const message =
      `PATIENT REQUEST / COMPLAINT\n\n` +
      `Name: ${f.get("name")}\n` +
      `Mobile: ${f.get("mobile")}\n` +
      `Request Type: ${f.get("requestType")}\n` +
      `Message: ${f.get("message")}\n\n` +
      `Please review this request.`;
    window.open(`https://wa.me/${CONFIG.WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`, "_blank");
    form.reset();
    showFormNote("complaint-note");
  });
}

function showFormNote(id) {
  const note = document.getElementById(id);
  if (!note) return;
  note.classList.add("visible");
  setTimeout(() => note.classList.remove("visible"), 6000);
}

function setYear() {
  document.querySelectorAll(".current-year").forEach((el) => {
    el.textContent = new Date().getFullYear();
  });
}
